<?php
/**
 * @package    Error 404
 * @subpackage Components
 * components/com_error404/error404.php
 * @link http://www.cdprof.com
 * @license    GNU/GPL
 */

// No direct access

defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('joomla.application.component.controller');

/**
 *Admin site error404 Component Controller
 *
 * @package    error404
 * @subpackage Components
 */
class errors404Controller extends JController
{
	/**
	 * Method to display the view
	 *
	 * @access    public
	 */
	
function display()
	{
		parent::display();
	}
	
	
}
