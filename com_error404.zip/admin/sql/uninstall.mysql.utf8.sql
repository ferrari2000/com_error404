DROP TABLE `#__error404`;
DROP TABLE `#__error404_stats`;
