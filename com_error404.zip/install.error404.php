<?php
echo "The component has been installed.";
?>
