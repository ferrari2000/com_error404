<?php
echo "The component has been desinstalled.";
?>
